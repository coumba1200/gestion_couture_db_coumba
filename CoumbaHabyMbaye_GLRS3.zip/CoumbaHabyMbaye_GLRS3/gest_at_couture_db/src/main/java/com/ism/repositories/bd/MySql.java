package com.ism.repositories.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.ism.entities.Categorie;
import com.ism.repositories.ITables;

public class MySql<T> {

    protected Connection getConnection() throws ClassNotFoundException, SQLException {
        // Chargement du Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Créer l'objet de connection
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/mettre le nom de la base de donnée créée", "root", "");
    }

    protected void closeResources(Connection conn, Statement statement, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.out.println("Erreur lors de la fermeture des ressources: " + e.getMessage());
        }
    }
}

public class CategorieRepository extends MySql<Categorie> implements ITables<Categorie> {

    @Override
    public int delete(int id) {
        // TODO: implémenter la suppression
        return 0;
    }

    @Override
    public ArrayList<Categorie> findAll() {
        ArrayList<Categorie> categories = new ArrayList<>();
        Connection conn = null;
        Statement statement = null;
        ResultSet rs = null;

        try {
            conn = getConnection();
            statement = conn.createStatement();
            rs = statement.executeQuery("SELECT id, libelle FROM mettre le nom de table");

            while (rs.next()) {
                Categorie categorie = new Categorie(rs.getInt("id"), rs.getString("libelle"));
                categories.add(categorie);
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erreur: " + e.getMessage());
        } finally {
            closeResources(conn, statement, rs);
        }

        return categories;
    }

    @Override
    public Categorie findById(int id) {
        Categorie categorie = null;
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet rs = null;

        try {
            conn = getConnection();
            String sql = "SELECT id, libelle FROM mettre le nom de table WHERE id=?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, id);
            rs = statement.executeQuery();

            if (rs.next()) {
                categorie = new Categorie(rs.getInt("id"), rs.getString("libelle"));
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erreur: " + e.getMessage());
        } finally {
            closeResources(conn, statement, rs);
        }

        return categorie;
    }

    @Override
    public int indexOf(int id) {
        // TODO: implémenter la recherche de l'indice
        return 0;
    }

    @Override
    public int insert(Categorie data) {
        int nbrLigne = 0;
        Connection conn = null;
        PreparedStatement statement = null;

        try {
            conn = getConnection();
            String sql = "INSERT INTO `mettre le nom de table` (`libelle`) VALUES (?)";
            statement = conn.prepareStatement(sql);
            statement.setString(1, data.getLibelle());
            nbrLigne = statement.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erreur: " + e.getMessage());
        } finally {
            closeResources(conn, statement, null);
        }

        return nbrLigne;
    }

    @Override
    public int update(Categorie data) {
        int nbrLigne = 0;
        Connection conn = null;
        PreparedStatement statement = null;

        try {
            conn = getConnection();
            String sql = "UPDATE `mettre le nom de table` SET `libelle`=? WHERE `id`=?";
            statement = conn.prepareStatement(sql);
            statement.setString(1, data.getLibelle());
            statement.setInt(2, data.getId());
            nbrLigne = statement.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Erreur: " + e.getMessage());
        } finally {
            closeResources(conn, statement, null);
        }

        return nbrLigne;
    }
}

// public class MySql<T> {

//     protected Connection connexion() throws ClassNotFoundException, SQLException {
//         // Chargement du Driver
//         Class.forName("com.mysql.cj.jdbc.Driver");

//         // Créer l'objet de connection
//         return DriverManager.getConnection("jdbc:mysql://localhost:3306/mettre le nom de la base de donnée créée", "root", "");
//     }

//     protected void closeResources(Connection conn, Statement statement, ResultSet rs) {
//         try {
//             if (rs != null) {
//                 rs.close();
//             }
//             if (statement != null) {
//                 statement.close();
//             }
//             if (conn != null) {
//                 conn.close();
//             }
//         } catch (SQLException e) {
//             System.out.println("Erreur lors de la fermeture des ressources: " + e.getMessage());
//         }
//     }

//     protected ResultSet executeSelect(String query, Object... params) throws SQLException, ClassNotFoundException {
//         Connection conn = null;
//         PreparedStatement statement = null;
//         ResultSet rs = null;

//         try {
//             conn = connexion();
//             statement = conn.prepareStatement(query);

//             // Remplir les paramètres de la requête
//             for (int i = 0; i < params.length; i++) {
//                 statement.setObject(i + 1, params[i]);
//             }

//             // Exécuter la requête SELECT
//             rs = statement.executeQuery();
//             return rs;
//         } finally {
//             closeResources(conn, statement, null);
//         }
//     }

//     protected int executeUpdate(String query, Object... params) throws SQLException, ClassNotFoundException {
//         Connection conn = null;
//         PreparedStatement statement = null;

//         try {
//             conn = connexion();
//             statement = conn.prepareStatement(query);

//             // Remplir les paramètres de la requête
//             for (int i = 0; i < params.length; i++) {
//                 statement.setObject(i + 1, params[i]);
//             }

//             // Exécuter la requête UPDATE
//             return statement.executeUpdate();
//         } finally {
//             closeResources(conn, statement, null);
//         }
//     }
// }

