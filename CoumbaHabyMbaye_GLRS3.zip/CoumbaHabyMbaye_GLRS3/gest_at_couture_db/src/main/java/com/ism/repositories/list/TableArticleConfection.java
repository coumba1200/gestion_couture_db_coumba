package com.ism.repositories.list;

import com.ism.entities.ArticleConfection;
public class TableArticleConfection extends Table <ArticleConfection>{
   
}
