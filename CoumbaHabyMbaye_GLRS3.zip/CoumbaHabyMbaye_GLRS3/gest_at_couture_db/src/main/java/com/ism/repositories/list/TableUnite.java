package com.ism.repositories.list;

import com.ism.entities.Unite;

public class TableUnite extends Table<Unite>{


}
