package com.ism.repositories.list;

import com.ism.entities.Categorie;

public class TableCategorie extends Table <Categorie>{

    
    
}
