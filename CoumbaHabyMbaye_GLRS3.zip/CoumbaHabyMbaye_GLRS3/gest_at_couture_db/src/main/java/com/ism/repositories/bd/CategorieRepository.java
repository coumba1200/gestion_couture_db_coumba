package com.ism.repositories.bd;

import com.ism.entities.Categorie;

public class CategorieRepository extends MySql<Categorie> implements ITables<Categorie> {
    //ici  on aura pas de methode car tout est hérité de MySql
}
